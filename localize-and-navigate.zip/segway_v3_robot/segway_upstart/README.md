segway_upstart
=============

This package contains a modified version of robot_upstart, specifically tailored for Segway RMP platforms.

For details on robot_upstart:
Clearpath Robotics presents a suite of scripts to assist with launching background ROS processes on Ubuntu Linux PCs. Please see the [generated documentation](http://docs.ros.org/api/robot_upstart/html/) and [ROS Wiki](http://wiki.ros.org/robot_upstart).
