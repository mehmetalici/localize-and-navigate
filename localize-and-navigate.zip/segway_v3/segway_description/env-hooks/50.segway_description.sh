export SEGWAY_DESCRIPTION=$(catkin_find --without-underlays --first-only segway_description urdf/description.xacro 2>/dev/null)
