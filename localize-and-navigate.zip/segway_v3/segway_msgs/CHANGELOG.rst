^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package segway_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.0.1 (2015-06-23)
------------------
* Initial release of Segway RMP V3 common packages
