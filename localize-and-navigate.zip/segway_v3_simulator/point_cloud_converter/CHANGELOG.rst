^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package pointcloud_converter
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.0.1 (2015-10-28)
------------------
* Initial release of Segway RMP V3 simulation. This package is needed
  in order to convert the VLP-16 Simulation data into PCL2
